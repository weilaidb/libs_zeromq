# Permission to Relicense under MPLv2

This is a statement by Quantum Corporation
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "vortechs2000", with
commit author "AJ Lewis aj.lewis@quantum.com", are copyright of Quantum Corporation.
This document hereby grants the libzmq project team to relicense libzmq, 
including all past, present and future contributions of the author listed above.

AJ Lewis
2019/02/21
